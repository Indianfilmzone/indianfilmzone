package com.hackathon.genie.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.hackathon.genie.MainActivity;
import com.hackathon.genie.R;
import com.hackathon.genie.util.AppController;
import com.hackathon.genie.util.Constants;
import com.hackathon.genie.util.URLs;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignUp extends AppCompatActivity implements View.OnClickListener{


    //Views
    private EditText editTextEmail;
    private EditText editTextOtp;

    private Button buttonEnter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        //Initiailizing views
        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextOtp = (EditText) findViewById(R.id.editTextOtp);

        buttonEnter = (Button) findViewById(R.id.buttonEnter);

        buttonEnter.setOnClickListener(this);

        //If the user is already logged in
        //Starting chat room
        if(AppController.getInstance().isLoggedIn()){
            finish();
            startActivity(new Intent(this, MainActivity.class));
        }
    }

    @Override
    public void onClick(View view) {
        //registerUser();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Checking if user is logged in
        if(AppController.getInstance().isLoggedIn()){
            finish();
            startActivity(new Intent(this, MainActivity.class));
        }
    }

    //Method to register user
    private void registerUser() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Entering chat room");
        progressDialog.show();


        final String email = editTextEmail.getText().toString().trim();
        final String otp = editTextOtp.getText().toString().trim();
        final String token=AppController.getInstance().getSharedPreferences().getString(getString(R.string.FCM_TOKEN), Constants.BLANK);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URLs.URL_REGISTER,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.hide();
                        try {
                            JSONObject obj = new JSONObject(response);
                            int id = obj.getInt("id");
                            String name = obj.getString("name");
                            String email = obj.getString("email");
                            String mobile = obj.getString("mobile");
                            String profileImage = obj.getString("image");
                            String status = obj.getString("status");

                            //Login user
                            AppController.getInstance().loginUser(id,name,email,mobile,profileImage,status);

                            //Starting chat room we need to create this activity
                            startActivity(new Intent(SignUp.this, MainActivity.class));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("otp", otp);
                params.put("email", email);
                params.put("token", token);
                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(stringRequest);
    }
}
