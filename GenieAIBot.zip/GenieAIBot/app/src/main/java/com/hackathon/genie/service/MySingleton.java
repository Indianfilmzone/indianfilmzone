package com.hackathon.genie.service;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

/**
 * Created by poonam on 10/9/2016.
 */

public class MySingleton {
    public static MySingleton mInstance;
    public static Context context;
    public RequestQueue requestQueue;


    private MySingleton(Context context){
        MySingleton.context =context;
        this.requestQueue=getRequestQueue();
    }
    public RequestQueue getRequestQueue(){
        if(null == requestQueue){
            requestQueue = Volley.newRequestQueue(context.getApplicationContext());
        }
        return requestQueue;
    }

    public static synchronized MySingleton getmInstance(Context context){
        if(null== mInstance){
            mInstance= new MySingleton(context);
        }
        return mInstance;
    }

    public<T> void addToRequestQueue(Request<T> request){
        getRequestQueue().add(request);
    }
}
