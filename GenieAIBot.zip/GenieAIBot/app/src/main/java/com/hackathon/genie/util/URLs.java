package com.hackathon.genie.util;

import com.android.volley.Request;

import java.util.Map;

/**
 * Created by poonam on 10/10/2016.
 */

public class URLs {
    //for android simulator
    //public static final String ROOT_URL = "http://10.0.2.2:8012/fcmdemo/";
    //for genemotion
    public static final String ROOT_URL = "http://10.0.3.2:8012/fcmdemo/";


    public static final String URL_INDEX = ROOT_URL + "index.php";
    public static final String URL_REGISTER = ROOT_URL + "register";
    public static final String URL_STORE_TOKEN = ROOT_URL + "storefcmtoken/";
    public static final String URL_FETCH_MESSAGES = ROOT_URL + "messages";
    public static final String URL_SEND_MESSAGE = ROOT_URL + "send";

    public static String getUrl(final String path){
        final StringBuilder builder=new StringBuilder(URLs.ROOT_URL);
        builder.append(path);
        return builder.toString();
    }
    public static String getUrl(final String path ,final Map<String, String> params){
        final StringBuilder builder=new StringBuilder(URLs.ROOT_URL);
        builder.append(path);
        if(!params.isEmpty()) {
            builder.append(Constants.QUESTION);
        }
        for (String key: params.keySet())
        {
            builder.append(key).append(Constants.COLON).append(params.get(key));
        }
        return builder.toString();
    }
}
