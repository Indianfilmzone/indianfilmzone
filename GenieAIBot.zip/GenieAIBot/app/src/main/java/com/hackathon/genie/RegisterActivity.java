package com.hackathon.genie;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.hackathon.genie.service.MySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    private static final String TAG = "RegisterActivity";
    private AutoCompleteTextView inputEmail;
    private EditText inputOtp;
    private ProgressBar progressBar;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        inputEmail = (AutoCompleteTextView) findViewById(R.id.email);
        inputOtp = (EditText) findViewById(R.id.otpText);
        progressBar = (ProgressBar) findViewById(R.id.registerProgressBar);
        registerButton = (Button) findViewById(R.id.registerButton);
        checkUser();
    }


    private void checkUser() {
        final SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(getString(R.string.FCM_PREF), Context.MODE_PRIVATE);
        final String token = sharedPreferences.getString(getString(R.string.FCM_TOKEN), "");
        String JsonURL = "http://10.0.3.2:8012/fcmdemo/register.php";

        Map<String, String> params = new HashMap();
        params.put("fcm_token",token);
        JSONObject parameters = new JSONObject(params);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, JsonURL,parameters, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(final JSONObject response) {
                try
                {
                    Log.d("response",response.toString());
                final JSONObject obj = response.getJSONObject("user");
                    Log.d("response", obj.toString());
                    boolean userFound=obj.getBoolean("success");
                if(userFound)
                {
                    String name = obj.getString("userName");
                    String email = obj.getString("emailId");
                    setContentView(R.layout.activity_chat);
                }
                else
                {
                    setContentView(R.layout.activity_register);
                }
            }
            // Try and catch are included to handle any errors due to JSON
            catch (JSONException e) {
                Log.e(TAG,e.getMessage());
            }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(final VolleyError error) {
                Log.e("Volley", error.getMessage());
            }
        });

        MySingleton.getmInstance(RegisterActivity.this).addToRequestQueue(request);

    }

}
