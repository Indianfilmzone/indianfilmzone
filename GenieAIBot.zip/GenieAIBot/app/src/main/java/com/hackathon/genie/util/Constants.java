package com.hackathon.genie.util;

/**
 * Created by poonam on 10/10/2016.
 */

public class Constants {

    public static final String USER_ID = "userid";
    public static final String USER_NAME = "username";
    public static final String USER_EMAIL= "useremail";
    public static final String USER_MOBILE= "usermobile";
    public static final String USER_PROFILE_IMAGE= "profileImage";
    public static final String USER_STATUS= "status";

    public static final String IS_LOGGED_IN= "is_logged_in";
    public static final String PUSH_NOTIFICATION = "pushnotification";
    public static final int NOTIFICATION_ID = 235;

    public static final String COLON = ":";
    public static final String BLANK = "";
    public static final String QUESTION = "?";

}
