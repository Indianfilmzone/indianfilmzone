<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_HOST', 'localhost');
define('DB_NAME', 'gcm_chat');

define("GOOGLE_API_KEY", "AIzaSyDKk_ew7Vi4FZnMzu6GCY5nLb4xZG8muvI");

// push notification flags
define('PUSH_FLAG_CHATROOM', 1);
define('PUSH_FLAG_USER', 2);

?>
