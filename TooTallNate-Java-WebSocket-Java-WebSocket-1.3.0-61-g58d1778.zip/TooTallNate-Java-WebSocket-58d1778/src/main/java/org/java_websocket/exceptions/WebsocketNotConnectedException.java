package org.java_websocket.exceptions;

public class WebsocketNotConnectedException extends RuntimeException {

}
