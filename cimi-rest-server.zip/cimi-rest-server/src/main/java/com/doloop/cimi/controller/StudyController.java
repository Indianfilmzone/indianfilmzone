package com.doloop.cimi.controller;

import org.springframework.web.bind.annotation.RestController;

import com.doloop.cimi.repositories.StudyRepository;

import lombok.extern.slf4j.Slf4j;


/**
 * The Class StudyController.
 * 
 */
@RestController
@Slf4j
public class StudyController {

    private StudyRepository repository;


}
