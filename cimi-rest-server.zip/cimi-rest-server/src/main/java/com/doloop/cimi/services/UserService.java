package com.doloop.cimi.services;

import java.util.List;
import java.util.Optional;

import com.doloop.cimi.exceptions.RestException;
import com.doloop.cimi.model.User;

/**
 * The Interface UserService.
 */
public interface UserService {

	/**
	 * Find by id.
	 *
	 * @param userName the user name
	 * @return the user
	 * @throws Exception the exception
	 */
	User findById(final String userName) throws RestException;

	/**
	 * Adds the.
	 *
	 * @param user the user
	 * @return the user
	 * @throws Exception the exception
	 */
	User add(final User user) throws RestException;

	/**
	 * Update user.
	 *
	 * @param user the user
	 * @return the user
	 * @throws Exception the exception
	 */
	User updateUser(String id,final User user) throws RestException;

	/**
	 * Delete user by id.
	 *
	 * @param id the id
	 * @throws Exception the exception
	 */
	void deleteUserById(final String id) throws RestException;

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	List<User> findAll() throws RestException;

}
