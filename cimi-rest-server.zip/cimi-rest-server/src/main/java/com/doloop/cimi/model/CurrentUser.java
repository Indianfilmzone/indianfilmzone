package com.doloop.cimi.model;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;

import lombok.Getter;
import lombok.ToString;
@ToString
public class CurrentUser extends org.springframework.security.core.userdetails.User {

	@Getter
	private User user;
	public CurrentUser(User user) {
		super(user.getUserName(),user.getPassword(),AuthorityUtils.createAuthorityList(user.getRole()));
	}

	private String getId(){
		return this.user.getId();
	}
	private String getRole(){
		return this.user.getRole();
	}
}
