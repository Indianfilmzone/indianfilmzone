package com.doloop.cimi.controller;

import java.util.List;

import javax.validation.Valid;

import org.junit.AfterClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doloop.cimi.exceptions.RestException;
import com.doloop.cimi.model.User;
import com.doloop.cimi.repositories.UserRepository;
import com.doloop.cimi.services.UserService;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class UserController.
 */
@RestController
@Slf4j
public class UserController {

	/** The user service. */
	@Autowired
	private UserService userService;

	/**
	 * Gets the users.
	 *
	 * @return the users
	 */
	@RequestMapping("/user")
	public List<User> findAll() throws RestException {
		log.debug("Finding all users entries.");
		return userService.findAll();
	}

	/**
	 * Greeting.
	 *
	 * @param id
	 *            the id
	 * @return the user
	 * @throws Exception
	 *             the exception
	 */
	@GetMapping("/user/{id}")
	public User findById(@PathVariable("id") final String id) throws RestException {
		return userService.findById(id);
	}

	/**
	 * Save user.
	 *
	 * @param user
	 *            the user
	 * @return the user
	 * @throws Exception
	 *             the exception
	 */
	@PostMapping("/user")
	public User saveUser(@Valid @RequestBody final User user) throws RestException {
		log.debug("Adding a new user entry with information: {}", user);
		return userService.add(user);
	}

	/**
	 * Update user.
	 *
	 * @param user
	 *            the user
	 * @param id
	 *            the id
	 * @return the user
	 * @throws Exception
	 *             the exception
	 */
	@PutMapping(value = "/user/{id}")
	public User updateUser(@PathVariable("id") String id, @Valid @RequestBody final User user) throws RestException {
		log.debug("Updating a user entry with information: {}", user);
		return userService.updateUser(id, user);
	}

	/**
	 * Delete user.
	 *
	 * @param id
	 *            the id
	 * @return the user
	 */
	@DeleteMapping("/user/{id}")
	public String deleteUser(@PathVariable("id") final String id) throws RestException {
		log.debug("Deleting a user entry with id: {}", id);
		String message = "User deleted!";
		userService.deleteUserById(id);
		return message;
	}

}
