package com.doloop.cimi.model;

public enum Role {
	USER, ADMIN
}
