package com.doloop.cimi.utils;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.doloop.cimi.security.DatabaseAuthenticationProvider;

public class AppUtils {
	
	private static final Logger LOG = Logger.getLogger(AppUtils.class); 
	
	public static String getUserName(){
		 Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth.getName();
        
	}
	
	public static boolean isAuthenticated(){
		 Authentication auth = SecurityContextHolder.getContext().getAuthentication();
       return auth.isAuthenticated();
	}


}
