package com.doloop.cimi.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.doloop.cimi.model.Study;


public interface StudyRepository  extends MongoRepository<Study, String> {

    public List<Study> findByStudyName(String studyName);
}
