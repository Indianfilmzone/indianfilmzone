package com.doloop.cimi.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@ConfigurationProperties(prefix = "cimi")
@Slf4j
public class AppConfig {

	public String appName;

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		log.debug("AppName set to {}", appName);
		this.appName = appName;
	}

}
