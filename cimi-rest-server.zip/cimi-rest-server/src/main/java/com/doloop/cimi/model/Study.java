package com.doloop.cimi.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Study {

	@Id
	public String id;
	private String studyName;
	private String description;
	private String title;
	private String clinicalPhase;
	private String therapeuticArea;
	private List<Deliverable> deliverables;
	
	@DateTimeFormat(iso =ISO.DATE_TIME)
	private Date createdDate;
	
	@DateTimeFormat(iso =ISO.DATE_TIME)
	private Date modifiedDate;

	public Study() {
		
	}
	public Study(@JsonProperty("studyName") String studyName, @JsonProperty("deliverables") List<Deliverable> deliverables) {
		super();		
		this.studyName = studyName;		
		this.deliverables = deliverables;
	}


	public Study(String id, String studyName, String description, String title, String clinicalPhase,
			String therapeuticArea, List<Deliverable> deliverables) {
		super();
		this.id = id;
		this.studyName = studyName;
		this.description = description;
		this.title = title;
		this.clinicalPhase = clinicalPhase;
		this.therapeuticArea = therapeuticArea;
		this.deliverables = deliverables;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStudyName() {
		return studyName;
	}

	public void setStudyName(String studyName) {
		this.studyName = studyName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getClinicalPhase() {
		return clinicalPhase;
	}

	public void setClinicalPhase(String clinicalPhase) {
		this.clinicalPhase = clinicalPhase;
	}

	public String getTherapeuticArea() {
		return therapeuticArea;
	}

	public void setTherapeuticArea(String therapeuticArea) {
		this.therapeuticArea = therapeuticArea;
	}

	public List<Deliverable> getDeliverables() {
		return deliverables;
	}

	public void setDeliverables(List<Deliverable> deliverables) {
		this.deliverables = deliverables;
	}

	@Override
	public String toString() {
		return "Study [id=" + id + ", studyName=" + studyName + ", description=" + description + ", title=" + title
				+ ", clinicalPhase=" + clinicalPhase + ", therapeuticArea=" + therapeuticArea + ", deliverables="
				+ deliverables + "]";
	}
}
