package com.doloop.cimi.controller.handlers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.doloop.cimi.exceptions.RestException;
import com.doloop.cimi.model.ErrorMessage;
import com.doloop.cimi.model.ValidationError;
import com.doloop.cimi.utils.AppConstants;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class ControllerExceptionHandlerAdvice {

	@ExceptionHandler(RestException.class)
	public ResponseEntity<Object> handleRestException(final WebRequest request, final RestException restException) {
		log.error(restException.getMessage(), restException);

		final List<ValidationError> fieldErrors = restException.getFieldErrors();
		final ErrorMessage errorMessage = ErrorMessage.builder()
				// .stackTrace(restException.getStackTrace())
				.resource(restException.getResource()).message(restException.getMessage()).build();
		if (fieldErrors.size() > 0) {
			errorMessage.setFieldErrors(fieldErrors);
		}
		return new ResponseEntity<Object>(errorMessage, new HttpHeaders(), HttpStatus.FORBIDDEN);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> handleMethodArgumentNotValid(final WebRequest request,
			final MethodArgumentNotValidException methodArgumentNotValidException) {
		log.error(methodArgumentNotValidException.getMessage(), methodArgumentNotValidException);

		final List<ValidationError> fieldErrors = new ArrayList<ValidationError>();
		final Errors error = methodArgumentNotValidException.getBindingResult();

		final ErrorMessage errorMessage = ErrorMessage.builder().resource(error.getObjectName())
				.message(AppConstants.VALIDATION_FAILED)
				// .stackTrace(methodArgumentNotValidException.getStackTrace())
				.build();

		for (ObjectError objectError : error.getAllErrors()) {
			final FieldError fieldError = (FieldError) objectError;
			fieldErrors.add(ValidationError.builder().code(fieldError.getCode()).resource(fieldError.getObjectName())
					.field(fieldError.getField()).rejectedValue(fieldError.getRejectedValue())
					.message(objectError.getDefaultMessage()).build());
		}
		if (fieldErrors.size() > 0) {
			errorMessage.setFieldErrors(fieldErrors);
		}
		return new ResponseEntity<Object>(errorMessage, new HttpHeaders(), HttpStatus.FORBIDDEN);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleException(Exception exception, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		final ErrorMessage errorMessage = ErrorMessage.builder()
				// .stackTrace(exception.getStackTrace())
				.resource(AppConstants.UNKNOWN).message(exception.getMessage()).build();
		return new ResponseEntity<Object>(errorMessage, new HttpHeaders(), HttpStatus.FORBIDDEN);
	}

	/*
	 * @ExceptionHandler(Exception.class)
	 * 
	 * @ResponseStatus(HttpStatus.FORBIDDEN) public ModelAndView
	 * exception(Exception exception) { ModelAndView mav = new
	 * ModelAndView("exception"); mav.addObject("name",
	 * exception.getClass().getSimpleName()); mav.addObject("message",
	 * exception.getMessage()); return mav; }
	 */

}
