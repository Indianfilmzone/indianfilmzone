package com.doloop.cimi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class HomeController.
 * this is a test controller to check if server is running
 */
@Controller
@Slf4j
public class HomeController {

	/**
	 * Index.
	 *
	 * @return the string
	 */
	@RequestMapping("/")
    public String index(Model model) {
		log.debug("/ invoke ");
		model.addAttribute("applicationName", "CIMI");
        return "index";
    }
	
	@RequestMapping("/admin")
    public String greeting(@RequestParam(value="name", required=false, defaultValue="World") String name, Model model) {
        model.addAttribute("name", name);
        return "greeting";
    }
	
}
