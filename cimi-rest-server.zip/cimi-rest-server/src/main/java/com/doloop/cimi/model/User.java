package com.doloop.cimi.model;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.doloop.cimi.validator.Phone;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class User.
 */

/*
 * (non-Javadoc)
 * 
 * @see java.lang.Object#toString()
 */
@ToString

/*
 * (non-Javadoc)
 * 
 * @see java.lang.Object#hashCode()
 */
@EqualsAndHashCode
@Document(collection = "users")
@JsonIgnoreProperties(ignoreUnknown = true)
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@JsonProperty

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	@Getter
	@Setter
	private String id;

	/** The user name. */
	@JsonProperty

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	@Getter

	/**
	 * Sets the user name.
	 *
	 * @param userName
	 *            the new user name
	 */
	@Setter
	@NotNull(message = "User name must not be blank!")
	private String userName;

	/** The password. */
	@JsonProperty

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	@Getter

	/**
	 * Sets the password.
	 *
	 * @param password
	 *            the new password
	 *            min 8 character
	 */
	@Setter
	@Size(min=8)
	private String password;

	/** The first name. */
	@JsonProperty

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	@Getter

	/**
	 * Sets the first name.
	 *
	 * @param firstName
	 *            the new first name
	 */
	@Setter
	private String firstName;

	/** The last name. */
	@JsonProperty

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	@Getter

	/**
	 * Sets the last name.
	 *
	 * @param lastName
	 *            the new last name
	 */
	@Setter
	private String lastName;

	/** The role. */
	@JsonProperty

	/**
	 * Gets the role.
	 *
	 * @return the role
	 */
	@Getter

	/**
	 * Sets the role.
	 *
	 * @param role
	 *            the new role
	 */
	@Setter
	private String role;

	/** The email. */
	@JsonProperty

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	@Getter

	/**
	 * Sets the email.
	 *
	 * @param email
	 *            the new email
	 */
	@Setter
	@Email
	private String email;

	/** The mobile. */
	@JsonProperty

	/**
	 * Gets the mobile.
	 *
	 * @return the mobile
	 */
	@Getter

	/**
	 * Sets the mobile.
	 *
	 * @param mobile
	 *            the new mobile
	 */
	@Setter
	//@Phone
	private String mobile;

	/** The work phone. */
	@JsonProperty

	/**
	 * Gets the work phone.
	 *
	 * @return the work phone
	 */
	@Getter

	/**
	 * Sets the work phone.
	 *
	 * @param workPhone
	 *            the new work phone
	 */
	@Setter
	private String workPhone;

	/** The avatar. */
	@JsonProperty

	/**
	 * Gets the avatar.
	 *
	 * @return the avatar
	 */
	@Getter

	/**
	 * Sets the avatar.
	 *
	 * @param avatar
	 *            the new avatar
	 */
	@Setter
	private String avatar;

	/** The active. */
	@JsonProperty

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	@Getter

	/**
	 * Sets the active.
	 *
	 * @param active
	 *            the new active
	 */
	@Setter
	private boolean active = true;

	/** The dob. */
	@JsonProperty
	@DateTimeFormat(pattern = "MM/dd/yyyy")
	private Date dob;

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	@Getter

	/**
	 * Sets the token.
	 *
	 * @param token
	 *            the new token
	 */
	@Setter
	private String token;

	/** The created date. */
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date createdDate;

	/** The modified date. */
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date modifiedDate;

	/**
	 * Instantiates a new user.
	 *
	 */
	public User() {
		super();
	}

	/**
	 * Instantiates a new user.
	 *
	 * @param id
	 *            the id
	 */
	public User(String id) {
		this.id = id;
	}

	/**
	 * Instantiates a new user.
	 *
	 * @param id
	 *            the id
	 * @param userName
	 *            the user name
	 * @param role
	 *            the role
	 */
	@JsonCreator
	@PersistenceConstructor
	public User(@JsonProperty("_id") String id, @JsonProperty("userName") String userName,
			@JsonProperty("role") String role) {
		this.userName = userName;
		this.role = role;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Builder
	public User(String userName, String password, String firstName, String lastName, String role, String email,
			String mobile, String workPhone, String avatar, boolean active, Date dob) {
		super();
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.role = role;
		this.email = email;
		this.mobile = mobile;
		this.workPhone = workPhone;
		this.avatar = avatar;
		this.active = active;
		this.dob = dob;
	}
}
