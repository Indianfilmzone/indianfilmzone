package com.doloop.cimi.utils;

public interface AppConstants {
	
	public static final String VALIDATION_FAILED="Validation failed";
	public static final String UNKNOWN="UnKnown";

}
