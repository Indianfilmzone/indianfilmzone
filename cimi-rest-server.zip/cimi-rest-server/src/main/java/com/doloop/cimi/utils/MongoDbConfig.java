package com.doloop.cimi.utils;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import com.doloop.cimi.model.Deliverable;
import com.doloop.cimi.model.Study;
import com.doloop.cimi.repositories.StudyRepository;

//@Component
public class MongoDbConfig implements CommandLineRunner {

	private static final Logger LOG = Logger.getLogger(MongoDbConfig.class); 
	@Autowired
	private StudyRepository repository;

	@Override
	public void run(String... args) throws Exception {

		repository.deleteAll();

		// save a couple of Study
		repository.save(new Study("Study1", new ArrayList<>()));

		// Create some recognitions
		List<Deliverable> deliverableList = new ArrayList<>();
		deliverableList.add(new Deliverable());
		deliverableList.add(new Deliverable());
		repository.save(new Study("Study2", deliverableList));

		// fetch all colleagues
		System.out.println("Study found with findAll():");
		System.out.println("-------------------------------");
		for (Study study : repository.findAll()) {
			System.out.println(study);
		}
		System.out.println();

		// fetch an individual Study
		System.out.println("Study found with findByFirstName('Study1'):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByStudyName("Study1"));

		System.out.println("Study found with findByLastName('Study2'):");
		System.out.println("--------------------------------");
		for (Study study : repository.findByStudyName("Study2")) {
			System.out.println(study);
		}

	}
}
