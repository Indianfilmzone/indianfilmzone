package com.doloop.cimi.repositories;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.doloop.cimi.model.User;

/**
 * The Interface UserRepository.
 */
public interface UserRepository extends MongoRepository<User, String> {

	// QueryDslPredicateExecutor<User>
	/**
	 * Find by user name.
	 *
	 * @param userName the user name
	 * @return the optional
	 */
	Optional<User> findByUserName(String userName);

	/**
	 * Find by first name.
	 *
	 * @param firstNam the first nam
	 * @return the optional
	 */
	Optional<User> findByFirstName(String firstNam);

	/**
	 * Find one by id.
	 *
	 * @param id the id
	 * @return the user
	 */
	Optional<User> findOneById(String id);

}
