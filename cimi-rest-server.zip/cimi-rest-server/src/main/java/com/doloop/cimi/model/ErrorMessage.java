package com.doloop.cimi.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorMessage {
	
	@Getter
	@Setter
	private String resource;

	@Getter
	@Setter
	private String message;
	@Getter
	@Setter
	private StackTraceElement[] stackTrace;

	@Getter
	@Setter
	private List<ValidationError> fieldErrors;

	public ErrorMessage(final String resource,final String message,final StackTraceElement[] stackTrace) {
		this.resource = resource;
		this.message = message;
		this.stackTrace = stackTrace;
	}

	public ErrorMessage() {
		super();
	}

	@Builder
	public ErrorMessage(final String resource,final String message,final StackTraceElement[] stackTrace,
			final List<ValidationError> fieldErrors) {
		super();
		this.resource = resource;
		this.message = message;
		this.stackTrace = stackTrace;
		this.fieldErrors = fieldErrors;

	}

}