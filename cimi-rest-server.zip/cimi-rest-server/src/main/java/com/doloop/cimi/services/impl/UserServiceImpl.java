package com.doloop.cimi.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.doloop.cimi.exceptions.RestException;
import com.doloop.cimi.model.User;
import com.doloop.cimi.repositories.UserRepository;
import com.doloop.cimi.services.UserService;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class UserServiceImpl.
 */
@Service
@Slf4j
public class UserServiceImpl implements UserService {

	/** mongodb Collection name */
	private static final String RESOURCE = "user";

	/** The user repository. */
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private MongoTemplate mongoTemplate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.doloop.cimi.services.UserService#findAll()
	 */
	@Override
	public List<User> findAll() {
		return userRepository.findAll( new Sort(Sort.Direction.ASC));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.doloop.cimi.services.UserService#add(com.doloop.cimi.model.User)
	 */
	@Override
	public User add(final User user) throws RestException {
		log.debug("Adding a new user entry with information: {}", user);

		final User userToAdd = User.builder().userName(user.getUserName()).firstName(user.getFirstName())
				.lastName(user.getLastName()).email(user.getEmail()).mobile(user.getMobile()).build();
		return userRepository.save(userToAdd);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.doloop.cimi.services.UserService#updateUser(com.doloop.cimi.model.
	 * User)
	 */
	@Override
	public User updateUser(final String id, final User user) throws RestException {

		final User userToUpdate = findById(id);
		userToUpdate.setFirstName(user.getFirstName());
		userToUpdate.setLastName(user.getLastName());
		userToUpdate.setEmail(user.getEmail());
		userToUpdate.setMobile(user.getMobile());
		return userRepository.save(userToUpdate);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.doloop.cimi.services.UserService#deleteUserById(java.lang.String)
	 */
	@Override
	public void deleteUserById(final String id) throws RestException {
		log.debug("Deleting a user entry with id: {}", id);
		final User user = findById(id);
		userRepository.delete(user);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.doloop.cimi.services.UserService#findById(java.lang.String)
	 */
	@Override
	public User findById(final String id) throws RestException {

		final Optional<User> found = userRepository.findOneById(id);
		
		
		
		log.debug("Found to-do entry: {}", found);

		if (!found.isPresent()) {
			throw new RestException(RESOURCE, "No to-entry found with id: " + id);
		}

		return found.get();
	}

}
